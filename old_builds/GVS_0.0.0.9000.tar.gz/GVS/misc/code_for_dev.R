library(devtools)
#devtools::create("C:/Users/Brian Maitner/Desktop/current_projects/RGVS/")

devtools::load_all()


devtools::document()
devtools::install()

file.remove(list.files("tests/fixtures/",
                       full.names = TRUE))

devtools::test()


devtools::build(path = "old_builds/")

#Check spelling
  spell_check()

#final check
  devtools::check()

#check on rhub
  #rhub::rhub_setup()
  #rhub::rhub_doctor()
  rhub::rhub_check() #1:4

  # ubuntu-latest on GitHub
  # macos-13 on GitHub
  # macos-latest on GitHub
  # windows-latest on GitHub

#check win devel
  check_win_devel()

#check mac
  check_mac_release()

#update cran comments
  #usethis::use_cran_comments()

# devtools::release()


  #testing url: "http://vegbiendev.nceas.ucsb.edu:7775/gvs_api.php"
  #producton url: "https://gvsapi.xyz/gvs_api.php"
